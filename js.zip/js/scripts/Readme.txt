What is Javascript?
Answer:
	Javascript is a lightweight interpreted(or Just-in-time compiler) programming language.Before Js we web pages are static web pages.we can not interact with them. we cann access any website using web browser and web browser knows only html,css and js.
	js execustion is depends on js engine. Eg.chrome browser uses V8,Mozila firefox use spider monkey,safari uses js core and MS edge uses chakra js engine. Now every modern browser haves its own js engines.

What are the different data_types exist in JS?
Answer:Number,String,Boolean,undefined,null,array,object


What are variables?
Answer:	Variables are container that can store values.
eg. let age = 25;
	let name = "John";


/**///
